<?php

namespace App\Enums;

enum WeekScope: string
{
    case NEXT_WEEK = 'next';
}
